module.exports = 'Arte conceptual y diseño 3D'
